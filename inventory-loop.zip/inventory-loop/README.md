# Inventory Loop Script README
Version 1.0

## Overview
This script is intended to capture various inventory files on a Linus system and consolidate
the files into one file for easy inventory management.
## Folder Structure
## File Structure
## Next Steps

